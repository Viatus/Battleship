package com.example.battleship.game

enum class ShotResult {
    MISS, HIT, DESTROYED
}