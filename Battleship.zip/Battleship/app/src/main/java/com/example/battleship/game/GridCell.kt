package com.example.battleship.game

enum class GridCell {
    SEA, CHECKED, SHIP, HIT, DESTROYED
}